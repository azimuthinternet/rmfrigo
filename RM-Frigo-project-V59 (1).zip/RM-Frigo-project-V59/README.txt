RM Frigo V52
Novi zajednički template za stranice usluga / informativne stranice.
Prva izvedba:
- prodaja-klima-uredaja.html

Header i footer su preuzeti iz V51 globalnog site templatea.
Template je zamišljen za usluge poput:
- Prodaja klima uređaja
- Ugradnja klima uređaja
- Servis klima uređaja
- Klima uređaji bez vanjske jedinice
- Prodaja i ugradnja peći na pelet
- Prodaja i ugradnja ventilacijskih sustava
te buduću stranicu O nama.
